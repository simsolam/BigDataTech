Command to Run jar
Syntax: hadoop jar <Jar_FileName> <ClassPath> <Input_Folder> <Output_Folder>
Eg: 	hadoop jar Climate.jar ClimateData input output